//Mod
var mod = Vars.mods.locateMod("cheat");
mod.meta.displayName = "[yellow]Cheat[orange]MOD";
mod.meta.description = "@mod.cheat.description";
mod.meta.author = "[#ff0][#fff]paulieg626";

//Block
require("blocks/liquid");
require("blocks/power");
require("blocks/powerS");
require("blocks/wall");
require("blocks/turret");
require("blocks/value");
require("blocks/magic");
require("blocks/conv");
require("blocks/shield");
require("blocks/boost");
require("blocks/boost-128");
require("blocks/boost-64");
require("blocks/cc");
require("blocks/item");
require("blocks/skip");
require("blocks/command");

print("☆ CheatMod by paulieg626 ☆");